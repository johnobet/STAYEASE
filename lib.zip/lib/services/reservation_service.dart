import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/reservation_model.dart';

class ReservationService {
  ReservationService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  CollectionReference<Map<String, dynamic>> get _reservations => _firestore.collection('reservations');

  /// All reservations across every property this owner has. Filter client
  /// side by status for the Pending/All tabs — keeps this to a single
  /// index (ownerId + createdAt) instead of one per status.
  Stream<List<ReservationModel>> watchOwnerReservations(String ownerId) {
    return _reservations
        .where('ownerId', isEqualTo: ownerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => ReservationModel.fromMap(d.id, d.data())).toList());
  }

  Future<void> approve(String reservationId) {
    return _reservations.doc(reservationId).update({'status': ReservationStatus.approved.value});
  }

  Future<void> reject(String reservationId) {
    return _reservations.doc(reservationId).update({'status': ReservationStatus.rejected.value});
  }
}
