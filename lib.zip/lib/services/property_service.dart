import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/property_model.dart';
import '../models/room_model.dart';

class PropertyService {
  PropertyService({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  CollectionReference<Map<String, dynamic>> get _properties => _firestore.collection('boardingHouses');
  CollectionReference<Map<String, dynamic>> get _rooms => _firestore.collection('rooms');

  /// Live list of the properties this owner has listed, newest first.
  Stream<List<PropertyModel>> watchOwnerProperties(String ownerId) {
    return _properties
        .where('ownerId', isEqualTo: ownerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => PropertyModel.fromMap(d.id, d.data())).toList());
  }

  /// Creates a boardingHouse doc, then a matching first room so the
  /// property is immediately reservable — no "add property with zero
  /// rooms" dead end.
  Future<String> createPropertyWithFirstRoom({
    required PropertyModel property,
    required String roomNumber,
    required String roomType,
    required double roomPrice,
    required int roomCapacity,
    required List<String> roomAmenities,
  }) async {
    final propertyRef = _properties.doc();
    await propertyRef.set(property.toMap());

    final room = RoomModel(
      id: '',
      boardingHouseId: propertyRef.id,
      roomNumber: roomNumber,
      type: roomType,
      price: roomPrice,
      capacity: roomCapacity,
      amenities: roomAmenities,
      status: 'available',
    );
    await _rooms.add(room.toMap());

    return propertyRef.id;
  }

  Stream<List<RoomModel>> watchRoomsForProperty(String boardingHouseId) {
    return _rooms
        .where('boardingHouseId', isEqualTo: boardingHouseId)
        .snapshots()
        .map((snap) => snap.docs.map((d) => RoomModel.fromMap(d.id, d.data())).toList());
  }

  Future<void> setPropertyStatus(String propertyId, String status) {
    return _properties.doc(propertyId).update({'status': status});
  }
}
