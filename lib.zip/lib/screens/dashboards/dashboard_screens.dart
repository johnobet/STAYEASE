import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/widgets/buttons/app_button.dart';
import '../../features/owner/owner_dashboard_screen.dart' as owner_feature;
import '../../features/tenant/tenant_dashboard_screen.dart' as tenant_feature;
import '../../models/user_model.dart';
import '../../services/auth_service.dart';

/// Shared shell for the still-placeholder Admin dashboard. Gets replaced
/// by its real feature build in a later phase (not prioritized — no
/// admin-specific demo requirement for the midterm).
class _DashboardScaffold extends StatelessWidget {
  const _DashboardScaffold({required this.title, required this.user});

  final String title;
  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.l),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Welcome, ${user.name.split(' ').first}', style: AppTypography.headingL),
            const SizedBox(height: AppSpacing.xs),
            Text(
              'Signed in as ${user.email} · ${user.role.value}',
              style: AppTypography.bodyM.copyWith(color: AppColors.textSecondary),
            ),
            const Spacer(),
            AppButton(
              label: 'Sign out',
              variant: AppButtonVariant.secondary,
              onPressed: () => AuthService().signOut(),
              fullWidth: true,
            ),
          ],
        ),
      ),
    );
  }
}

/// Thin wrapper so AuthGate's call signature doesn't need to change —
/// delegates straight to the real Tenant feature build.
class TenantDashboardScreen extends StatelessWidget {
  const TenantDashboardScreen({super.key, required this.user});
  final UserModel user;

  @override
  Widget build(BuildContext context) => tenant_feature.TenantDashboardScreen(user: user);
}

/// Same pattern — delegates to the real Owner feature build now that
/// My Properties + Reservation Requests exist.
class OwnerDashboardScreen extends StatelessWidget {
  const OwnerDashboardScreen({super.key, required this.user});
  final UserModel user;

  @override
  Widget build(BuildContext context) =>
      owner_feature.OwnerDashboardScreen(ownerId: user.uid, ownerName: user.name);
}

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key, required this.user});
  final UserModel user;

  @override
  Widget build(BuildContext context) =>
      _DashboardScaffold(title: 'Admin Dashboard', user: user);
}
