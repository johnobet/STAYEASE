import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/buttons/app_button.dart';
import '../../../core/widgets/inputs/app_text_field.dart';
import '../../../models/property_model.dart';
import '../../../services/property_service.dart';

const _amenityOptions = [
  'Wi-Fi', 'Private bathroom', 'Shared bathroom', 'Kitchen', 'Laundry',
  'Parking', 'Air conditioning', 'Fan', 'Study area', 'Water supply',
  'Electricity inclusion',
];

const _roomTypes = ['Private', 'Shared', 'Bedspace'];

class AddPropertyScreen extends StatefulWidget {
  const AddPropertyScreen({super.key, required this.ownerId});
  final String ownerId;

  @override
  State<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends State<AddPropertyScreen> {
  final _service = PropertyService();

  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _addressController = TextEditingController();
  final _houseRulesController = TextEditingController();
  final _roomNumberController = TextEditingController(text: '101');
  final _priceController = TextEditingController();
  final _capacityController = TextEditingController(text: '1');

  final Set<String> _selectedAmenities = {};
  String _roomType = _roomTypes.first;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _addressController.dispose();
    _houseRulesController.dispose();
    _roomNumberController.dispose();
    _priceController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _error = null);

    if (_nameController.text.trim().isEmpty || _addressController.text.trim().isEmpty) {
      setState(() => _error = 'Property name and address are required.');
      return;
    }
    final price = double.tryParse(_priceController.text.trim());
    if (price == null || price <= 0) {
      setState(() => _error = 'Enter a valid room price.');
      return;
    }
    final capacity = int.tryParse(_capacityController.text.trim()) ?? 1;

    setState(() => _loading = true);
    try {
      await _service.createPropertyWithFirstRoom(
        property: PropertyModel(
          id: '',
          ownerId: widget.ownerId,
          name: _nameController.text.trim(),
          description: _descriptionController.text.trim(),
          address: _addressController.text.trim(),
          amenities: _selectedAmenities.toList(),
          houseRules: _houseRulesController.text
              .split('\n')
              .map((r) => r.trim())
              .where((r) => r.isNotEmpty)
              .toList(),
        ),
        roomNumber: _roomNumberController.text.trim(),
        roomType: _roomType,
        roomPrice: price,
        roomCapacity: capacity,
        roomAmenities: _selectedAmenities.toList(),
      );
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      setState(() => _error = 'Could not save this property. Please try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add property')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(AppSpacing.l, AppSpacing.l, AppSpacing.l, AppSpacing.xxxl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _SectionLabel('PROPERTY INFO'),
              const SizedBox(height: AppSpacing.m),
              AppTextField(label: 'NAME', hint: "e.g. Maria's Boarding House", controller: _nameController),
              const SizedBox(height: AppSpacing.l),
              AppTextField(
                label: 'ADDRESS',
                hint: 'Street, barangay, municipality',
                controller: _addressController,
                prefixIcon: Icons.place_rounded,
              ),
              const SizedBox(height: AppSpacing.l),
              AppTextField(
                label: 'DESCRIPTION',
                hint: 'What makes this place a good stay?',
                controller: _descriptionController,
              ),
              const SizedBox(height: AppSpacing.xl),

              _SectionLabel('AMENITIES'),
              const SizedBox(height: AppSpacing.m),
              Wrap(
                spacing: AppSpacing.s,
                runSpacing: AppSpacing.s,
                children: _amenityOptions.map((amenity) {
                  final selected = _selectedAmenities.contains(amenity);
                  return GestureDetector(
                    onTap: () => setState(() {
                      selected ? _selectedAmenities.remove(amenity) : _selectedAmenities.add(amenity);
                    }),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 140),
                      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.m, vertical: AppSpacing.s),
                      decoration: BoxDecoration(
                        color: selected ? AppColors.navy800 : AppColors.surface,
                        borderRadius: BorderRadius.circular(AppRadius.pill),
                        border: Border.all(color: selected ? AppColors.navy800 : AppColors.borderSubtle),
                      ),
                      child: Text(
                        amenity,
                        style: AppTypography.bodyS.copyWith(
                          color: selected ? AppColors.textOnDark : AppColors.textSecondary,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: AppSpacing.xl),

              _SectionLabel('HOUSE RULES'),
              const SizedBox(height: AppSpacing.m),
              AppTextField(
                label: 'ONE RULE PER LINE',
                hint: 'No visitors after 10PM\nNo smoking indoors',
                controller: _houseRulesController,
              ),
              const SizedBox(height: AppSpacing.xl),

              _SectionLabel('FIRST ROOM'),
              const SizedBox(height: AppSpacing.xs),
              Text(
                "Every property needs at least one room to be reservable. You can add more rooms later.",
                style: AppTypography.bodyS,
              ),
              const SizedBox(height: AppSpacing.m),
              Row(
                children: [
                  Expanded(
                    child: AppTextField(label: 'ROOM NO.', controller: _roomNumberController),
                  ),
                  const SizedBox(width: AppSpacing.m),
                  Expanded(
                    child: AppTextField(
                      label: 'CAPACITY',
                      controller: _capacityController,
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.l),
              Text('ROOM TYPE', style: AppTypography.label),
              const SizedBox(height: AppSpacing.s),
              Row(
                children: _roomTypes.map((type) {
                  final selected = _roomType == type;
                  return Padding(
                    padding: const EdgeInsets.only(right: AppSpacing.s),
                    child: GestureDetector(
                      onTap: () => setState(() => _roomType = type),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.l, vertical: AppSpacing.s),
                        decoration: BoxDecoration(
                          color: selected ? AppColors.gold100 : AppColors.surface,
                          borderRadius: BorderRadius.circular(AppRadius.pill),
                          border: Border.all(color: selected ? AppColors.gold500 : AppColors.borderSubtle),
                        ),
                        child: Text(
                          type,
                          style: AppTypography.bodyS.copyWith(
                            color: selected ? AppColors.gold600 : AppColors.textSecondary,
                            fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: AppSpacing.l),
              AppTextField(
                label: 'MONTHLY PRICE (₱)',
                hint: '2500',
                controller: _priceController,
                keyboardType: TextInputType.number,
              ),

              if (_error != null) ...[
                const SizedBox(height: AppSpacing.l),
                Container(
                  padding: const EdgeInsets.all(AppSpacing.m),
                  decoration: BoxDecoration(
                    color: AppColors.dangerBg,
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Text(_error!, style: AppTypography.bodyS.copyWith(color: AppColors.danger)),
                ),
              ],

              const SizedBox(height: AppSpacing.xxl),
              AppButton(
                label: 'Save property',
                onPressed: _loading ? null : _submit,
                loading: _loading,
                fullWidth: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 3, height: 14, color: AppColors.gold500),
        const SizedBox(width: AppSpacing.s),
        Text(text, style: AppTypography.label),
      ],
    );
  }
}
