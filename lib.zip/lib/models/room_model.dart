class RoomModel {
  const RoomModel({
    required this.id,
    required this.boardingHouseId,
    required this.roomNumber,
    required this.type,
    required this.price,
    required this.capacity,
    this.amenities = const [],
    this.status = 'available',
  });

  final String id;
  final String boardingHouseId;
  final String roomNumber;
  final String type; // Private | Shared | Bedspace
  final double price;
  final int capacity;
  final List<String> amenities;
  final String status; // available | occupied | unavailable

  Map<String, dynamic> toMap() {
    return {
      'boardingHouseId': boardingHouseId,
      'roomNumber': roomNumber,
      'type': type,
      'price': price,
      'capacity': capacity,
      'amenities': amenities,
      'status': status,
    };
  }

  factory RoomModel.fromMap(String id, Map<String, dynamic> map) {
    return RoomModel(
      id: id,
      boardingHouseId: map['boardingHouseId'] as String? ?? '',
      roomNumber: map['roomNumber'] as String? ?? '',
      type: map['type'] as String? ?? 'Private',
      price: (map['price'] as num?)?.toDouble() ?? 0,
      capacity: (map['capacity'] as num?)?.toInt() ?? 1,
      amenities: List<String>.from(map['amenities'] as List? ?? const []),
      status: map['status'] as String? ?? 'available',
    );
  }
}
