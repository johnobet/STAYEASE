import 'package:cloud_firestore/cloud_firestore.dart';

/// Statuses per spec section 18.
enum ReservationStatus { pending, approved, rejected, reserved, checkedIn, completed, cancelled }

extension ReservationStatusX on ReservationStatus {
  String get value {
    switch (this) {
      case ReservationStatus.checkedIn:
        return 'checkedIn';
      default:
        return name;
    }
  }

  static ReservationStatus fromString(String? value) {
    switch (value) {
      case 'approved':
        return ReservationStatus.approved;
      case 'rejected':
        return ReservationStatus.rejected;
      case 'reserved':
        return ReservationStatus.reserved;
      case 'checkedIn':
        return ReservationStatus.checkedIn;
      case 'completed':
        return ReservationStatus.completed;
      case 'cancelled':
        return ReservationStatus.cancelled;
      case 'pending':
      default:
        return ReservationStatus.pending;
    }
  }

  String get label {
    switch (this) {
      case ReservationStatus.pending:
        return 'Pending';
      case ReservationStatus.approved:
        return 'Approved';
      case ReservationStatus.rejected:
        return 'Rejected';
      case ReservationStatus.reserved:
        return 'Reserved';
      case ReservationStatus.checkedIn:
        return 'Checked In';
      case ReservationStatus.completed:
        return 'Completed';
      case ReservationStatus.cancelled:
        return 'Cancelled';
    }
  }
}

class ReservationModel {
  const ReservationModel({
    required this.id,
    required this.tenantId,
    required this.ownerId,
    required this.boardingHouseId,
    required this.roomId,
    required this.checkInDate,
    required this.status,
    this.paymentStatus = 'unpaid',
    this.createdAt,
    // Denormalized fields (written at creation time) so owner/tenant lists
    // don't need an extra fetch per row just to show a name/price.
    this.tenantName = '',
    this.propertyName = '',
    this.roomLabel = '',
    this.priceLabel = '',
  });

  final String id;
  final String tenantId;
  final String ownerId;
  final String boardingHouseId;
  final String roomId;
  final DateTime checkInDate;
  final ReservationStatus status;
  final String paymentStatus; // unpaid | paid
  final DateTime? createdAt;

  final String tenantName;
  final String propertyName;
  final String roomLabel;
  final String priceLabel;

  Map<String, dynamic> toMap() {
    return {
      'tenantId': tenantId,
      'ownerId': ownerId,
      'boardingHouseId': boardingHouseId,
      'roomId': roomId,
      'checkInDate': Timestamp.fromDate(checkInDate),
      'status': status.value,
      'paymentStatus': paymentStatus,
      'createdAt': FieldValue.serverTimestamp(),
      'tenantName': tenantName,
      'propertyName': propertyName,
      'roomLabel': roomLabel,
      'priceLabel': priceLabel,
    };
  }

  factory ReservationModel.fromMap(String id, Map<String, dynamic> map) {
    final checkIn = map['checkInDate'];
    final createdAt = map['createdAt'];
    return ReservationModel(
      id: id,
      tenantId: map['tenantId'] as String? ?? '',
      ownerId: map['ownerId'] as String? ?? '',
      boardingHouseId: map['boardingHouseId'] as String? ?? '',
      roomId: map['roomId'] as String? ?? '',
      checkInDate: checkIn is Timestamp ? checkIn.toDate() : DateTime.now(),
      status: ReservationStatusX.fromString(map['status'] as String?),
      paymentStatus: map['paymentStatus'] as String? ?? 'unpaid',
      createdAt: createdAt is Timestamp ? createdAt.toDate() : null,
      tenantName: map['tenantName'] as String? ?? '',
      propertyName: map['propertyName'] as String? ?? '',
      roomLabel: map['roomLabel'] as String? ?? '',
      priceLabel: map['priceLabel'] as String? ?? '',
    );
  }

  ReservationModel copyWith({ReservationStatus? status}) {
    return ReservationModel(
      id: id,
      tenantId: tenantId,
      ownerId: ownerId,
      boardingHouseId: boardingHouseId,
      roomId: roomId,
      checkInDate: checkInDate,
      status: status ?? this.status,
      paymentStatus: paymentStatus,
      createdAt: createdAt,
      tenantName: tenantName,
      propertyName: propertyName,
      roomLabel: roomLabel,
      priceLabel: priceLabel,
    );
  }
}
