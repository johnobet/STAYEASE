import 'package:cloud_firestore/cloud_firestore.dart';

class PropertyModel {
  const PropertyModel({
    required this.id,
    required this.ownerId,
    required this.name,
    required this.description,
    required this.address,
    this.latitude,
    this.longitude,
    this.photos = const [],
    this.amenities = const [],
    this.houseRules = const [],
    this.rating = 0.0,
    this.verified = false,
    this.status = 'active',
    this.createdAt,
  });

  final String id;
  final String ownerId;
  final String name;
  final String description;
  final String address;
  final double? latitude;
  final double? longitude;
  final List<String> photos;
  final List<String> amenities;
  final List<String> houseRules;
  final double rating;
  final bool verified;
  final String status; // active | inactive
  final DateTime? createdAt;

  Map<String, dynamic> toMap() {
    return {
      'ownerId': ownerId,
      'name': name,
      'description': description,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'photos': photos,
      'amenities': amenities,
      'houseRules': houseRules,
      'rating': rating,
      'verified': verified,
      'status': status,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  factory PropertyModel.fromMap(String id, Map<String, dynamic> map) {
    final timestamp = map['createdAt'];
    return PropertyModel(
      id: id,
      ownerId: map['ownerId'] as String? ?? '',
      name: map['name'] as String? ?? '',
      description: map['description'] as String? ?? '',
      address: map['address'] as String? ?? '',
      latitude: (map['latitude'] as num?)?.toDouble(),
      longitude: (map['longitude'] as num?)?.toDouble(),
      photos: List<String>.from(map['photos'] as List? ?? const []),
      amenities: List<String>.from(map['amenities'] as List? ?? const []),
      houseRules: List<String>.from(map['houseRules'] as List? ?? const []),
      rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
      verified: map['verified'] as bool? ?? false,
      status: map['status'] as String? ?? 'active',
      createdAt: timestamp is Timestamp ? timestamp.toDate() : null,
    );
  }
}
